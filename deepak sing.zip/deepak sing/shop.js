let cloths = document.getElementById("cloths");
let reviews = document.getElementById("reviews");
let contact = document.getElementById("contacts");
let blogs = document.getElementById("blogs");

cloths.addEventListener("click",function()
{
    cloths.style.color="red";
    reviews.style.color="black";
    contact.style.color="black";
    blogs.style.color="black";
    
})

reviews.addEventListener("click",function()
{
    cloths.style.color="black";
    reviews.style.color="red";
    contact.style.color="black";
    blogs.style.color="black";
    
})
contact.addEventListener("click",function()
{
    cloths.style.color="black";
    reviews.style.color="black";
    contact.style.color="red";
    blogs.style.color="black";
    
})
blogs.addEventListener("click",function()
{
    cloths.style.color="black";
    reviews.style.color="black";
    contact.style.color="black";
    blogs.style.color="red";
    
})

let login = document.getElementById("login");
login.addEventListener("click",function() {
    let loginPage = document.querySelector(".loginPage");
    loginPage.style.display="block"
})
let loged = document.getElementById("loged");
loged.addEventListener("click",function(){
      let email = document.getElementById("email");
      let pass = document.getElementById("pass");
      if(email.value == "" || pass.value == ""){
        alert("please Enter Email password")
      }else{
        alert("You Loged In")
        document.querySelector(".loginPage").style.display="none";
      }
})


 let submit = document.getElementById("submit");
 submit.addEventListener("click",function(){
  
  let names = document.getElementById("name");
  let password = document.getElementById("pass");
    
     if(names.value == "" || password == ""){
      alert("please Enter Name and password")
     }else{
      alert("Thanks for  connecting")
     }
 })
